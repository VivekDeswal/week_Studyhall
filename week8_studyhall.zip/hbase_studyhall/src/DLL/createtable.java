package DLL;
import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableExistsException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HBaseAdmin;

public class createtable {

public static void main(String[] args) throws IOException{
		
		Configuration cg = HBaseConfiguration.create();
		@SuppressWarnings({ "deprecation" })
		HBaseAdmin admin = new HBaseAdmin(cg);
		
		HTableDescriptor tableDescriptor = new HTableDescriptor(TableName.valueOf("sh"));
		
		tableDescriptor.addFamily(new HColumnDescriptor("Name"));
		tableDescriptor.addFamily(new HColumnDescriptor("Contact no"));
		
		try{
			admin.createTable(tableDescriptor);
			System.out.println("Table Created");
			}
			catch(TableExistsException e){
				System.out.println("A table already exist.\n" + e.toString());
			}
			admin.close();
		
	}
}
