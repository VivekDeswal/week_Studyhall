package DLL;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.MasterNotRunningException;
import org.apache.hadoop.hbase.client.HBaseAdmin;

public class is_enable {
public static void main(String[] args) throws MasterNotRunningException, IOException {
		
	Configuration cg = HBaseConfiguration.create();
	@SuppressWarnings({ "deprecation", "resource" })
	HBaseAdmin admin = new HBaseAdmin(cg);
	
	Boolean bool = admin.isTableDisabled("sh");
	System.out.println("Is Table enable: " + bool);
	}

}
